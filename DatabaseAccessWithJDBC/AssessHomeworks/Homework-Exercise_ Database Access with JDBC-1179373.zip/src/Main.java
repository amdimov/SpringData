import com.mysql.jdbc.Driver;

import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    private static final String CONNECTION_STRING = "jdbc:mysql://localhost:3306/";
    private static final String DATABASE = "minions_db";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";
    private static Connection connection;
    private static Scanner scanner;

    public static void main(String[] args) throws SQLException {
        scanner = new Scanner(System.in);

        connection = setupConnection();

        System.out.println("Type task number:");

        int taskNumber = Integer.parseInt(scanner.nextLine());

        switch (taskNumber){
            case 2:
                taskTwo();
                break;
            case 3:
                taskThree();
                break;
            case 4:
                taskFour();
                break;
            case 5:
                taskFive();
                break;
            case 7:
                taskSeven();
                break;
            case 8:
                taskEight();
                break;
            case 9:
                taskNine();
                break;
            default:
                System.out.println("Incorrect task number");
        }
    }

    private static void taskFour() throws SQLException {
        System.out.println("Type input:");

        String[] minionInput = scanner.nextLine().split(": ")[1].split(" ");

        String minionName = minionInput[0];

        int minionAge = Integer.parseInt(minionInput[1]);

        String town = minionInput[2];

        Integer townId = null;

        String villainName = scanner.nextLine().split(": ")[1];

        Integer villainId = null;

        PreparedStatement townStatement = connection.prepareStatement("SELECT t.id, t.name FROM towns t WHERE t.name = ?;");

        townStatement.setString(1, town);

        ResultSet townResult = townStatement.executeQuery();

        if(townResult.next()){
            townId = townResult.getInt(1);
        }else{
            PreparedStatement insertTownStatement = connection.prepareStatement("INSERT INTO towns (towns.name) VALUES (?);");

            insertTownStatement.setString(1, town);

            insertTownStatement.executeUpdate();

            PreparedStatement selectTownStatement = connection.prepareStatement("SELECT t.id FROM towns t WHERE t.name = ?;");

            selectTownStatement.setString(1, town);

            ResultSet townIdResult = selectTownStatement.executeQuery();

            if(townIdResult.next()){
                townId = townIdResult.getInt(1);

                System.out.printf("Town %s was added to the database.%n", town);
            }
        }

        PreparedStatement insertMinionStatement = connection.prepareStatement("INSERT INTO minions (minions.name, minions.age, minions.town_id) VALUES (?, ?, ?);");

        insertMinionStatement.setString(1, minionName);
        insertMinionStatement.setInt(2, minionAge);
        insertMinionStatement.setInt(3, townId);

        insertMinionStatement.executeUpdate();

        PreparedStatement selectMinionIdStatement = connection.prepareStatement("SELECT m.id FROM minions m WHERE m.name = ?;");

        selectMinionIdStatement.setString(1, minionName);

        ResultSet minionIdResult = selectMinionIdStatement.executeQuery();

        minionIdResult.next();

        int minionId = minionIdResult.getInt(1);

        PreparedStatement selectVillainIdStatement = connection.prepareStatement("SELECT v.id FROM villains v WHERE v.name = ?;");

        selectVillainIdStatement.setString(1, villainName);

        ResultSet villainIdResult = selectVillainIdStatement.executeQuery();

        if(villainIdResult.next()){
            villainId = villainIdResult.getInt(1);
        }else{
            PreparedStatement insertNewVillainStatement = connection.prepareStatement("INSERT INTO villains (villains.name, villains.evilness_factor) VALUES (?, ?);");

            insertNewVillainStatement.setString(1, villainName);
            insertNewVillainStatement.setString(2, "evil");

            insertNewVillainStatement.executeUpdate();

            PreparedStatement selectNewVillainIdStatement = connection.prepareStatement("SELECT v.id FROM villains v WHERE v.name = ?;");

            selectNewVillainIdStatement.setString(1, villainName);

            ResultSet newVillainIdResult = selectNewVillainIdStatement.executeQuery();

            newVillainIdResult.next();

            villainId = newVillainIdResult.getInt(1);

            System.out.printf("Villain %s was added to the database.%n", villainName);
        }

        PreparedStatement insertMappingStatement = connection.prepareStatement("INSERT INTO minions_villains VALUES (?, ?);");

        insertMappingStatement.setInt(1, minionId);
        insertMappingStatement.setInt(2, villainId);

        insertMappingStatement.executeUpdate();

        System.out.printf("Successfully added %s to be minion of %s.%n", minionName, villainName);
    }

    private static void taskNine() throws SQLException {
        System.out.println("Type minion id:");

        int id = Integer.parseInt(scanner.nextLine());

        CallableStatement increaseAgeProcedureCall = connection.prepareCall("{ CALL usp_get_older(?) }");

        increaseAgeProcedureCall.setInt(1, id);

        ResultSet minionResult = increaseAgeProcedureCall.executeQuery();

        if(minionResult.next()){
            System.out.printf("%s %d%n", minionResult.getString(1), minionResult.getInt(2));
        }
    }

    private static void taskEight() throws SQLException {
        System.out.println("Type minion Ids separated by space:");
        List<Integer> minionIds = Arrays.stream(scanner.nextLine().split(" ")).map(id -> Integer.parseInt(id)).collect(Collectors.toList());

        for(Integer minionId : minionIds){
            PreparedStatement increaseAge = connection.prepareStatement("UPDATE minions m SET m.age = m.age + 1, m.name = LOWER(m.name) WHERE m.id = ?;");

            increaseAge.setInt(1, minionId);

            increaseAge.executeUpdate();
        }

        PreparedStatement selectMinions = connection.prepareStatement("SELECT m.name, m.age FROM minions m;");

        ResultSet minions = selectMinions.executeQuery();

        while(minions.next()){
            System.out.printf("%s %d%n", minions.getString(1), minions.getInt(2));
        }
    }

    private static void taskSeven() throws SQLException {
        PreparedStatement selectMinionNames = connection.prepareStatement("SELECT m.name FROM minions m;");

        ResultSet minionNames = selectMinionNames.executeQuery();

        List<String> names = new ArrayList<>();

        while(minionNames.next()){
            names.add(minionNames.getString(1));
        }

        int counter = 0;

        for(int i = 0; i < names.size(); i++){
            String name;
            if(i%2 == 0) {
                name = names.get(i - counter);
            }else{
                name = names.get(names.size() - 1 - counter);

                counter++;
            }

            System.out.printf("%s%n", name);
        }
    }

    private static void taskFive() throws SQLException {
        System.out.println("Type country name:");

        String countryName = scanner.nextLine();

        PreparedStatement updateStatement = connection.prepareStatement("UPDATE towns t SET t.name = UPPER(t.name) WHERE t.country = ?;");

        updateStatement.setString(1, countryName);

        int rowsUpdated = updateStatement.executeUpdate();

        if(rowsUpdated > 0){
            System.out.printf("%d town names were affected.%n", rowsUpdated);

            PreparedStatement selectUpdatedTownNames = connection.prepareStatement("SELECT t.name FROM towns t WHERE t.country = ?;");

            selectUpdatedTownNames.setString(1, countryName);

            ResultSet updatedTownNames = selectUpdatedTownNames.executeQuery();

            List<String> townNames = new ArrayList<>();

            while(updatedTownNames.next()){
                townNames.add(updatedTownNames.getString(1));
            }

            System.out.println(townNames.toString());
        }else{
            System.out.println("No town names were affected.");
        }
    }

    private static void taskThree() throws SQLException {
        System.out.println("Type villain id:");

        int villainId = Integer.parseInt(scanner.nextLine());

        PreparedStatement preparedStatement = connection.prepareStatement("SELECT v.name FROM villains v WHERE v.id = ?;");

        preparedStatement.setInt(1, villainId);

        ResultSet selectVillain = preparedStatement.executeQuery();

        if(!selectVillain.isBeforeFirst()){
            System.out.printf("No villain with ID %d exists in the database.", villainId);
            return;
        }

        selectVillain.next();

        String villainName = selectVillain.getString(1);

        PreparedStatement selectMinions = connection.prepareStatement("SELECT DISTINCT m.name, m.age FROM minions m " +
                "    JOIN minions_villains mv on m.id = mv.minion_id " +
                "WHERE mv.villain_id = ?;");

        selectMinions.setInt(1, villainId);

        ResultSet minions = selectMinions.executeQuery();

        int counter = 0;

        System.out.printf("Villain: %s%n", villainName);

        while(minions.next()){
            System.out.printf("%d. %s %d%n", ++counter, minions.getString("name"), minions.getInt("age"));
        }
    }

    private static void taskTwo() throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT v.name, COUNT(DISTINCT m.id) AS c FROM villains v " +
                "    JOIN minions_villains mv on v.id = mv.villain_id " +
                "    JOIN minions m on mv.minion_id = m.id " +
                "GROUP BY v.name " +
                "HAVING c > 15 " +
                "ORDER BY c DESC;");

        ResultSet rs = preparedStatement.executeQuery();

        while(rs.next()){
            System.out.printf("%s %d %n", rs.getString(1), rs.getInt(2));
        }
    }

    private static Connection setupConnection() throws SQLException {
        Properties props = new Properties();
        props.setProperty("user", USERNAME);
        props.setProperty("password", PASSWORD);

        return DriverManager.getConnection(CONNECTION_STRING + DATABASE, props);
    }
}
